package com.revature.strings;

import com.revature.model.Hero;

/*
 * Remember that you cannot extend the String class as it is a final class.
 */
public class Strings /*extends String*/{

	public static void main(String...args) {
		
		/*
		 * Strings that are created this way are placed in the String Pool.
		 */
		String literal = "String Literal"; //string literal
		String literal2 = "String Literal 2";
		String literal3 = "string literal";
		
		//Some useful/common String methods
		System.out.println(literal.length());
		
		System.out.println(literal.toLowerCase());
		
		System.out.println(literal.equals(literal2));
		
		System.out.println(literal.equalsIgnoreCase(literal3));
		
		System.out.println(literal.concat(" " + literal2));
		
		//You can even format objects as Strings using the static "format" method.
		
		//Float formatting
		System.out.println(String.format("%f", 10.0));
		
		//String formatting
		System.out.println(String.format("%s", 10.0));
		
		//Adding a newline using the format method
		System.out.println(String.format("%n", ""));
		
		//Digit formatting
		System.out.println(String.format("%d", 89));
	
	//Recall that there are two ways to compare objects in Java:
		
		//1) Using the == operator; this reference equality.
		//2) Using the "equals" method that is inherited from the object class.
		
		Hero h = new Hero();
		Hero h2 = new Hero();
		
		h.setAccessory("belt");
		h2.setAccessory("belt");
		
		System.out.println(h == h2);
		System.out.println(h.equals(h2));
		
		//This is slightly different with Strings because of the way they are treated
		//in memory.
		
		//Java checks the String pool for a String with the contents "superman". No such
		//String exists at this point, so Java creates this String.
		String hero = "superman";
		//Java checks the String pool for a String with the contents "superboy". No such
		//String exists at this point, so Java creates this String.
		String sidekick = "superboy";
		//Java checks the String Pool for a string with the contents "superman" and this
		//time it finds that String because it already exists as it was created two lines
		//ago.
		String hero2 = "superman"; //does not create a String.
		//This is bad practice as it forces Java to allocate memory for a new String
		//despite the fact that a String with these contents already exists in memory.
		String hero3 = new String("superman");
		
		System.out.println(hero.equals(hero2)); //true
		System.out.println(hero == hero2); //true
		System.out.println(hero == hero3); //false
		System.out.println(hero.equals(hero3)); //still true
		
		//Fortunately, if you use the String constructor, there is a way to tell 
		//Java to search the String pool for a String with matching content (or to
		//simply tell Java to add your newly constructed string to the pool!)
		
		hero3 = hero3.intern();
		
		System.out.println(hero == hero3);
		
		//StringBuilder
		
		System.out.println("================StringBuilder================");
		
		StringBuilder sBuilder = new StringBuilder("a string");
		String notSBuilder = "a string";
		
		//Concat something to notSBuilder
		notSBuilder.concat(" plus something else");
		System.out.println(notSBuilder); //the underlying string has not changed!
		
		//Concat something to sBuilder
		sBuilder.append(" plus something else");
		System.out.println(sBuilder); //our StringBuilder object has been modified!
	
		/*
		 * If you are not working in a multithreaded environment, prefer StringBuilder
		 * as it is faster than the thread-safe StringBuffer.
		 */
		System.out.println("==========================StringBuffer===================");
		StringBuffer sBuffer = new StringBuffer("a string");
		
	}
}
