package com.revature.model;

public class Villain extends SuperPoweredPerson{
	
	public Villain() {
		super();
	}


	public Villain(String power, String codeName, String catchPhrase, String weakness, String accessory,
			int numberOfLives) {
		super();
		this.power = power;
		this.codeName = codeName;
		this.catchPhrase = catchPhrase;
		this.weakness = weakness;
		this.accessory = accessory;
		this.numberOfLives = numberOfLives;
	}


	public String getPower() {
		return power;
	}


	public void setPower(String power) {
		this.power = power;
	}


	public String getCodeName() {
		return codeName;
	}


	public void setCodeName(String codeName) {
		this.codeName = codeName;
	}


	public String getCatchPhrase() {
		return catchPhrase;
	}


	public void setCatchPhrase(String catchPhrase) {
		this.catchPhrase = catchPhrase;
	}


	public String getWeakness() {
		return weakness;
	}


	public void setWeakness(String weakness) {
		this.weakness = weakness;
	}


	public String getAccessory() {
		return accessory;
	}


	public void setAccessory(String accessory) {
		this.accessory = accessory;
	}


	public int getNumberOfLives() {
		return numberOfLives;
	}


	public void setNumberOfLives(int numberOfLives) {
		this.numberOfLives = numberOfLives;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((accessory == null) ? 0 : accessory.hashCode());
		result = prime * result + ((catchPhrase == null) ? 0 : catchPhrase.hashCode());
		result = prime * result + ((codeName == null) ? 0 : codeName.hashCode());
		result = prime * result + numberOfLives;
		result = prime * result + ((power == null) ? 0 : power.hashCode());
		result = prime * result + ((weakness == null) ? 0 : weakness.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Villain other = (Villain) obj;
		if (accessory == null) {
			if (other.accessory != null)
				return false;
		} else if (!accessory.equals(other.accessory))
			return false;
		if (catchPhrase == null) {
			if (other.catchPhrase != null)
				return false;
		} else if (!catchPhrase.equals(other.catchPhrase))
			return false;
		if (codeName == null) {
			if (other.codeName != null)
				return false;
		} else if (!codeName.equals(other.codeName))
			return false;
		if (numberOfLives != other.numberOfLives)
			return false;
		if (power == null) {
			if (other.power != null)
				return false;
		} else if (!power.equals(other.power))
			return false;
		if (weakness == null) {
			if (other.weakness != null)
				return false;
		} else if (!weakness.equals(other.weakness))
			return false;
		return true;
	}
	
	@Override
	public String toString() {
		return "Villain [power=" + power + ", codeName=" + codeName + ", catchPhrase=" + catchPhrase + ", weakness="
				+ weakness + ", accessory=" + accessory + ", numberOfLives=" + numberOfLives + "]";
	}


	@Override
	public void abstractMethod(int x) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void eat(String food) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void sleep(int hours) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void usePower() {
		// TODO Auto-generated method stub
		
	}
}
