package com.revature.interfaces;

/*
 * This is how we declare an interface. Note that the assumption is that an
 * interface is both public and abstract.
 * 
 * Because interfaces are abstract types, we cannot instantiate them.
 * 
 * Because interfaces are abstract, we are allowed to declare abstract
 * methods on them.
 * 
 * NOTE: Interfaces can't be final!
 */

public abstract interface InterfaceI {

	/*
	 * You are allowed to have fields on interfaces, but...
	 * 
	 * It has to be public, static, and final!
	 */
	
	public static final int i = 8;
	
	/*
	 * All methods, even concrete methods, on interfaces are public.
	 * You cannot make them private or protected.
	 */
	public abstract void method();
	
	/*
	 * This method is assumed to be public and abstract.
	 */
	void method3();
	
	/*
	 * DOES NOT COMPILE as you cannot define concrete methods on interfaces
	 * without using 1 of 2 special keywords.
	 */
//	public void method2() {
//		
//	}
	
	//If you want to have a method with an implementation on an interface, you
	//must do one of the following:
	
	//1) Use the static keyword in the method signature
	
	public static void methodB() {
		//Implementation
	}
	
	//2) Use the "default" keyword in the method signature
	//This keyword allows us to provide a default implementation for a method
	//on an interface.
	
	public default void methodC() {
		//Default Implementation
	}
}


/*
 * Interfaces can extend other interfaces! They are not obligated to
 * implement any inherited unimplemented methods as interfaces are
 * abstract.
 * 
 * Interfaces can extend multiple interfaces.
 */
interface InterfaceII extends InterfaceI{
	
}

/*
 * Classes can implement multiple interfaces...
 * 
 * but classes cannot extend more than one class!
 */
class InterfaceIIImplementation extends Thread implements InterfaceII{

	@Override
	public void method() {
		// TODO Auto-generated method stub
	}

	@Override
	public void method3() {
		// TODO Auto-generated method stub
	}
}