package com.revature.collections;

import java.util.HashSet;
import java.util.Set;

public class SetImplementations {

	public static void main(String...args) {
		
		Set<String> heroicPowers = new HashSet<>(); 
		
		//Recall that the order in which you insert these objects is not preserved!
		heroicPowers.add("flight");
		heroicPowers.add("laser vision");
		heroicPowers.add("super strength");
		//Recall also that sets do not support duplicates, which means that even though
		//we've attempted to add "flight" twice, it will not be reflected in our set
		//twice.
		heroicPowers.add("flight");
		
		System.out.println(heroicPowers);
		
//		heroicPowers.get(0); //DOES NOT COMPILE as there is no get() method on the set interface
		
		//If you want to access the elements of a set, you must iterate over the set.
		//I have to iterate over the entire set and find the object I'm looking for!
		for(String s : heroicPowers) {
			if(s.equals("laser vision")) {
				System.out.println(s);
			}
		}
	}
}
