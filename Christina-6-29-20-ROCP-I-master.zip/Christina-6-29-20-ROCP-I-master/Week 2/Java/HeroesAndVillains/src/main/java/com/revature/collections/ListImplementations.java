package com.revature.collections;

import java.util.ArrayList;
import java.util.List;

import com.revature.model.Hero;

public class ListImplementations {

	public static void main(String...args) {
		
		/*
		 * Note that by default you can add any type of object to a collection.
		 * This means that not all of the objects in the collection will have the
		 * same type. This is not the way you typically use collections!
		 */
		ArrayList myList = new ArrayList();
		
		List myList2 = new ArrayList();
		
		/*
		 * You can impose a type on a collection by using what is referred to as
		 * "generics". This ArrayList now can only hold objects of
		 * type "String". This means that if I attempt to add an object
		 * that is not a string to the ArrayList, this code won't
		 * compile.
		 */
		ArrayList<String> heroicPowers = new ArrayList<>();
		
		/*
		 * You should note that collections do NOT support primitives.
		 * This means that you cannot use a primitive type as your
		 * generic type.
		 */
		
//		ArrayList<int> nums = new ArrayList<>(); //DOES NOT COMPILE
		
		/*
		 * Let's add some powers to our array list! Our list is dynamic in size,
		 * so we are not limited to adding a maximum number of elements to the
		 * list!
		 */
		
		heroicPowers.add("flight");
		heroicPowers.add("super strength");
		heroicPowers.add("ice breath");
//		heroicPowers.add(new Hero()); //DOES NOT COMPILE
		
		System.out.println(heroicPowers);
		
		System.out.println(heroicPowers.get(2));
		
		System.out.println(heroicPowers.size());
		
		heroicPowers.remove("flight");
		
		System.out.println(heroicPowers);
		
		//As an aside, you can easily iterate over a collection with a for-each
		//loop. You can read this as "for each String s in heroicPowers". Note that you
		//have to iterate over each object in the collection if you're using this
		//enhanced for loop.
		
		for(String s : heroicPowers) {
			System.out.println(s);
		}
		
		//Traditional for loop
		
		for(int i = 0; i < heroicPowers.size(); i++) {
			System.out.println(heroicPowers.get(i));
		}
	}
}
