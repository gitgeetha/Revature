package com.revature.model;

/*
 * Abstract classes can inherit from other abstract classes.
 * 
 * Note that this abstract class does NOT have to implement the
 * unimplemented methods it has inherited.
 */
public abstract class SuperPoweredPerson extends Person{
	
	protected String power;
	protected String codeName;
	protected String catchPhrase;
	protected String weakness;
	protected String accessory;
	protected int numberOfLives;

	public abstract void usePower();
}
