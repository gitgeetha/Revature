package com.revature.model;

/*
 * An abstract class cannot be final as this means that we could never
 * inherit from this class. In other words, our abstract methods would 
 * never be inherited and therefore never implemented.
 */
public abstract class Person {
	
	protected String name;
	protected int age;
	protected int height;
	
	//This is an abstract method as it has no implementation!
	/*
	 * An abstract method cannot be final as this keyword prevents a method
	 * from being overridden. If an abstract method is overridden, it will
	 * never receive an implementation.
	 * 
	 * It also can't be private or have default access as this means that it won't inherited.
	 */
	public abstract void abstractMethod(int x);
	
	public abstract void eat(String food);
	
	public abstract void sleep(int hours);
	
	/*
	 * An abstract class is not required to have any abstract methods.
	 */
	
	/*
	 * Not everything has to be inherited in an abstract class. Concrete
	 * methods, for instance, can be private.
	 */
	private void concreteMethod() {
		
	}
	
}

/*
 * Concrete Class
 */
class NotAbstractClass{
	
	public void concreteMethod() {
		//Implementation here.
	}
	
	public static void main(String...args) {
		//You cannot instantiate abstract classes! DOES NOT COMPILE
//		Person p = new Person();
	}
	
	//DOES NOT COMPILE as you can only have abstract methods in abstract classes
//	public abstract void someMethod();
}
