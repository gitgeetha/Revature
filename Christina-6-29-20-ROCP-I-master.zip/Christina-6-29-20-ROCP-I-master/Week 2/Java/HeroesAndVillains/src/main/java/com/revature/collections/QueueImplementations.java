package com.revature.collections;

import java.util.Iterator;
import java.util.PriorityQueue;
import java.util.Scanner;

public class QueueImplementations {

	public static void main(String...args) {
		
		/*
		 * Do note that the PriorityQueue is a special implementation of the Queue interface
		 * that orders the objects according to a natural order. The natural order of Strings,
		 * for instance, is alphabetical order.
		 */
		PriorityQueue<String> heroicPowers = new PriorityQueue<>();
		
		/*
		 * Note that I can't simply remove "speed" before removing "flight" as "flight"
		 * is first in line.
		 */
		heroicPowers.add("flight");
		heroicPowers.add("speed");
		heroicPowers.add("zing power");
		heroicPowers.add("ice powers");
		
		System.out.println(heroicPowers);
		
		//How do I remove the heroic powers?
		heroicPowers.poll(); //this removes flight as it is first in line!
		heroicPowers.peek(); //this allows you to view the object at the front of the queue without removing it!
		
		System.out.println(heroicPowers);
		
		heroicPowers.poll();
		
		System.out.println(heroicPowers);
		
		/*
		 * Queue doesn't support random access, so you must iterate over it to access
		 * the elements in it.
		 */
		
		Iterator<String> it = heroicPowers.iterator();
		
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		
	}
}
