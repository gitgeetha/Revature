package com.revature.model;

public class SuperCharacter {

	private int id;
	private String codename;
	private String catchPhrase;
	private String accessory;
	private int superPowerId;
	private int superPetId;
	
	public SuperCharacter() {
		super();
	}

	public SuperCharacter(int id, String codename, String catchPhrase, String accessory, int superPowerId,
			int superPetId) {
		super();
		this.id = id;
		this.codename = codename;
		this.catchPhrase = catchPhrase;
		this.accessory = accessory;
		this.superPowerId = superPowerId;
		this.superPetId = superPetId;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCodename() {
		return codename;
	}

	public void setCodename(String codename) {
		this.codename = codename;
	}

	public String getCatchPhrase() {
		return catchPhrase;
	}

	public void setCatchPhrase(String catchPhrase) {
		this.catchPhrase = catchPhrase;
	}

	public String getAccessory() {
		return accessory;
	}

	public void setAccessory(String accessory) {
		this.accessory = accessory;
	}

	public int getSuperPowerId() {
		return superPowerId;
	}

	public void setSuperPowerId(int superPowerId) {
		this.superPowerId = superPowerId;
	}

	public int getSuperPetId() {
		return superPetId;
	}

	public void setSuperPetId(int superPetId) {
		this.superPetId = superPetId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((accessory == null) ? 0 : accessory.hashCode());
		result = prime * result + ((catchPhrase == null) ? 0 : catchPhrase.hashCode());
		result = prime * result + ((codename == null) ? 0 : codename.hashCode());
		result = prime * result + id;
		result = prime * result + superPetId;
		result = prime * result + superPowerId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SuperCharacter other = (SuperCharacter) obj;
		if (accessory == null) {
			if (other.accessory != null)
				return false;
		} else if (!accessory.equals(other.accessory))
			return false;
		if (catchPhrase == null) {
			if (other.catchPhrase != null)
				return false;
		} else if (!catchPhrase.equals(other.catchPhrase))
			return false;
		if (codename == null) {
			if (other.codename != null)
				return false;
		} else if (!codename.equals(other.codename))
			return false;
		if (id != other.id)
			return false;
		if (superPetId != other.superPetId)
			return false;
		if (superPowerId != other.superPowerId)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "SuperCharacter [id=" + id + ", codename=" + codename + ", catchPhrase=" + catchPhrase + ", accessory="
				+ accessory + ", superPowerId=" + superPowerId + ", superPetId=" + superPetId + "]";
	}
}
