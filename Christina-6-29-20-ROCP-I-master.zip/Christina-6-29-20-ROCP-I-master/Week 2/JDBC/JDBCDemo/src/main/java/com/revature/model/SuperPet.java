package com.revature.model;

public class SuperPet {

	private int id;
	private String codename;
	private String catchPhrase;
	private int superPowerId;
	private String petBreed;
	private String favoriteTreat;
	
	public SuperPet() {
		super();
	}

	public SuperPet(int id, String codename, String catchPhrase, int superPowerId, String petBreed,
			String favoriteTreat) {
		super();
		this.id = id;
		this.codename = codename;
		this.catchPhrase = catchPhrase;
		this.superPowerId = superPowerId;
		this.petBreed = petBreed;
		this.favoriteTreat = favoriteTreat;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCodename() {
		return codename;
	}

	public void setCodename(String codename) {
		this.codename = codename;
	}

	public String getCatchPhrase() {
		return catchPhrase;
	}

	public void setCatchPhrase(String catchPhrase) {
		this.catchPhrase = catchPhrase;
	}

	public int getSuperPowerId() {
		return superPowerId;
	}

	public void setSuperPowerId(int superPowerId) {
		this.superPowerId = superPowerId;
	}

	public String getPetBreed() {
		return petBreed;
	}

	public void setPetBreed(String petBreed) {
		this.petBreed = petBreed;
	}

	public String getFavoriteTreat() {
		return favoriteTreat;
	}

	public void setFavoriteTreat(String favoriteTreat) {
		this.favoriteTreat = favoriteTreat;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((catchPhrase == null) ? 0 : catchPhrase.hashCode());
		result = prime * result + ((codename == null) ? 0 : codename.hashCode());
		result = prime * result + ((favoriteTreat == null) ? 0 : favoriteTreat.hashCode());
		result = prime * result + id;
		result = prime * result + ((petBreed == null) ? 0 : petBreed.hashCode());
		result = prime * result + superPowerId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SuperPet other = (SuperPet) obj;
		if (catchPhrase == null) {
			if (other.catchPhrase != null)
				return false;
		} else if (!catchPhrase.equals(other.catchPhrase))
			return false;
		if (codename == null) {
			if (other.codename != null)
				return false;
		} else if (!codename.equals(other.codename))
			return false;
		if (favoriteTreat == null) {
			if (other.favoriteTreat != null)
				return false;
		} else if (!favoriteTreat.equals(other.favoriteTreat))
			return false;
		if (id != other.id)
			return false;
		if (petBreed == null) {
			if (other.petBreed != null)
				return false;
		} else if (!petBreed.equals(other.petBreed))
			return false;
		if (superPowerId != other.superPowerId)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "SuperPet [id=" + id + ", codename=" + codename + ", catchPhrase=" + catchPhrase + ", superPowerId="
				+ superPowerId + ", petBreed=" + petBreed + ", favoriteTreat=" + favoriteTreat + "]";
	}
}
