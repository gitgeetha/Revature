package com.revature.repository;

import java.util.List;

import com.revature.model.SuperPower;

public interface SuperPowerRepository {

	/*
	 * Let's declare some methods we think will be useful for interacting
	 * with our super_power entity in our database.
	 * 
	 * These methods are referred to as basic CRUD methods. CRUD
	 * stands for:
	 * 
	 * Create
	 * Read
	 * Update
	 * Delete
	 */
	
	List<SuperPower> findAllSuperPowers();
	SuperPower findSuperPowerById(int id);
	SuperPower findSuperPowerByName(String name);
	void insertSuperPower(SuperPower superPower);
	void deleteSuperPower(SuperPower superPower);
	void updateSuperPower(SuperPower superPower);
}
