--Let's create another user for this database!
--This has nothing to do with application logic!
create user newuser with password 'password';

--if I wanted to grant the new user some permissions, I could do
--that as the super user. I could also revoke some of that user's
--permissions.

revoke all privileges on database postgres from newuser;
revoke create on database postgres from newuser;
commit;

--will modify as I don't want this new user to be able to do
--anything!
create table newTable();
drop table newTable;