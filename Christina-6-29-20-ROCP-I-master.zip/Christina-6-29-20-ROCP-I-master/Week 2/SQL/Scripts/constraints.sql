select * from super_power;

--Let us add some constraints to our tables so that we can
--guarantee that all records have unique IDs.

drop table super_power;
create table super_power(
	id serial primary key, --this is an autoincrementing numeric data type
	powerName varchar
);

select * from super_power;

select * from super_character;

select * from super_pet;

--Let's establish some relationships between our entities!
--We've added some constraints to our super_character table
--so that our super character's codename must be unique.
/*
 * I've also specified that a super character's codename can't
 * be null!
 * 
 * I've additionally applied a default constraint to the
 * catchphrase column. Note that this constraint does not
 * apply to null inserts as this is very deliberate. It simply
 * applies to situations in which we insert nothing into the
 * column.
 * 
 * NOTE: A primary key is implied to be unique and not null.
 */
drop table super_character;
create table super_character(
	id serial primary key, --the name of my column is "id" and the data type is "numeric"
	codename varchar unique not null, --varchar is a data type used for text
	catchPhrase varchar default 'N/A',
	accessory varchar,
	super_age integer check (super_age > 0),
	superPower integer references super_power(id),
	/*
	 * This column's value logically depends on the super pet name
	 * that the super_pet foreign key references. The super_pet
	 * foreign key is determined by the super_character's ID.
	 * 
	 * If superpetname depends on the superpet id and the superpet id
	 * depends on the super_character id, what does the
	 * superpetname ultimately depend on?
	 * 
	 * superpetname -> superpet -> id
	 */
	superPetName varchar,
	superPet integer references super_pet (id) --this number references a super pet's ID
);

select * from super_character;
select * from super_power;

--I have deleted this record because the data is NOT atomic.
delete from super_power where id = 5;
insert into super_power values(default, 'flight, strength, lightning, fire');

--What purpose does the age column serve if you know the exact
--date I was born on?
create table tableA(
	address varchar,
	birthDate date,
	myAge numeric,
	constraint address_bd_pk primary key (address, birthDate)
);

select * from tableA;

insert into tableA values('cherry lane', '1993-03-10', 27);