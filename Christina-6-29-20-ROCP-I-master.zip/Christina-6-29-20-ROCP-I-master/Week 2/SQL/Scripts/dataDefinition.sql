--This is how you leave comments!
/*
 * You can also do multiline comments in here!
 */
drop table super_character;
create table super_character(
	id numeric primary key, --the name of my column is "id" and the data type is "numeric"
	codename varchar, --varchar is a data type used for text
	catchPhrase varchar,
	accessory varchar,
	superPower varchar,
	superPet varchar
);

drop table super_pet;
create table super_pet(
	id serial primary key,
	codeName varchar,
	catchPhrase varchar,
	superPower varchar,
	petBreed varchar, -- what type of animal is it?
	favoriteTreat varchar
);

drop table superPower;
create table superPower(
	id numeric,
	powerName varchar
);

--If you want to alter a table that already exists, you
--should use the "alter" keyword.

alter table superPower rename to super_power;
alter table superPet rename to super_pet;

