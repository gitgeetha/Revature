

--What if I want to insert a record of a super_character?
--I can use some DDL for this. to be exact, I can use
--an "insert" statement!

insert into super_character values(default, 'Sharkman', null, 
'Triton', 45, 3, 'Aquaspot', 1);
insert into super_character values(default, 'Wonder Lady', 'I will save you!', 'Whip',
33, 1, 'A cute cat', 2);

--NOTE: This is an alternative syntax for inserting into a table:

select * from super_character;
insert into super_character (id, codename, accessory, super_age, superpower, superpet)
values (default, 'Sharkboy', 'belt', 1, 1, 1);

insert into super_pet values(1, 'Aquaspot', 'Bark', 'Being a good boy', 
'Water Dog', 'Scooby Snacks');

insert into super_pet values(2, 'A cute cat', 'Meow', 'Purring loudly',
'A Cute Cat', 'vanilla ice cream');

insert into super_power values(1, 'Being a good boy');
insert into super_power values(2, 'Purring loudly');
insert into super_power values(3, 'Being really fast in water despite the fact that I am not a fish');
insert into super_power values(4, 'Being really strong and fast');

--We can also read from our tables by using the "select" keyword
select * from super_pet; -- the asterisk (*) denotes that I'm selecting all columns
select id, codename, superpower from super_pet;

--We can update our records by using the "update" keyword.
/*
 * Be sure that you always use your where clause when updating
 * or deleting a record as if you do not the update will be
 * applied to every single record! You can use any column in
 * your where clause.
 */

update super_pet 
set catchphrase = 'Growl' 
where codename = 'A cute cat' 
and id = 2;

update super_character 
set codename = 'Sharkman'
where codename = 'Fishman';

--if you wish to remove a record from a table, you must use a
-- "delete" statement. Again, be careful that you don't forget
-- your where clause.
delete from super_character where id = 2;

--Note that TCL is used heavily with DML as you will
--often want to finalize/revert changes that you have
--made using your DML!

commit;

select * from super_power;

begin transaction; -- this begins a transaction block
savepoint mySavePoint;
--If you make some inserts or updates that you do not want to
--persist, you can rollback your changes by moving back to a
--savepoint!
insert into super_power values(5, 'some power');

rollback to mySavePoint;
