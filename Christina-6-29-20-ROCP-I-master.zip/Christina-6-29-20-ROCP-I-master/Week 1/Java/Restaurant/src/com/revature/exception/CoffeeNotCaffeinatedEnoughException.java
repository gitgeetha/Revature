package com.revature.exception;

public class CoffeeNotCaffeinatedEnoughException extends Exception {

	/*
	 * A constructor for our exception
	 */
	public CoffeeNotCaffeinatedEnoughException(String message) {
		super(message);
	}
}
