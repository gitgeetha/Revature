package com.revature.exception;

/*
 * If you want to create your own exception, you only need to
 * extend the Exception class!
 */

public class ChristinaException extends Exception {

}
