package com.revature.model;

import com.revature.exception.InvalidAgeException;

public class PremiumCustomer implements java.io.Serializable {

	private String name;
	private String address;
	private String phoneNumber;
	private int age;
	private float rewardPoints;

	// Constructor with parameters
	public PremiumCustomer(String name, String address, String phoneNumber, int age, float rewardPoints) {
		this.name = name;
		this.address = address;
		this.phoneNumber = phoneNumber;
		this.age = age;
		this.rewardPoints = rewardPoints;
	}

	/*
	 * this is required for making java bean project.
	 */
	public PremiumCustomer() {
		super(); // call the Object class constructor.
	}

	/*
	 * this will check if the customer name is empty, then print message to the
	 * console.
	 */
	public void setName(String newName) {
		if (newName.isEmpty()) {
			System.out.println("The name can not be empty.");

		} else {
			this.name = newName;
		}
	}

	/*
	 * this will check if the customer address is empty, if empty then give message
	 * to the customer.
	 */
	public void setAddress(String newAddress) {
		if (newAddress.isEmpty()) {
			System.out.println("The address can not be empty.");

		} else {
			this.address = newAddress;
		}
	}

	/*
	 * this will check is the phone number is empty or invalid
	 */
	public void setPhoneNumber(String newPhoneNumber) {
		if (newPhoneNumber.isEmpty()) {
			System.out.println("The phone number can not be empty.");

		} else {

			this.phoneNumber = newPhoneNumber;
		}
	}

	/*
	 * This setAge() method will check the customer's age.
	 */
	public void setAge(int newAge) {
		if (newAge < 18) {
			try {

				throw new InvalidAgeException("You must be 18 or older.");
			} catch (InvalidAgeException e) {
				e.printStackTrace();
			}

		} // end if
		else {
			this.age = newAge;
		}

	}

	public void setRewardPoints(float newRewardPoints) {
		this.rewardPoints = newRewardPoints;
	}

	public String getName() {
		return this.name;
	}

	public String getAddress() {
		return this.address;
	}

	public String getPhoneNumber() {
		return this.phoneNumber;
	}

	public int getAge() {
		return this.age;
	}

	public float getRewardPoint() {
		return this.rewardPoints;
	}

	public float customerReward() {

		System.out.println(this.rewardPoints * 0.10f);
		return (this.rewardPoints * 0.10f);

	}

	public static void main(String[] args) {

		PremiumCustomer customer = new PremiumCustomer("Christina", "12345 Revature Drive, CA93125 Pacoima",
				"123-456-7890", 25, 100);
		customer.customerReward();
/*
 * Testing the Exception handing features
 */
		customer.setAge(20);
		System.out.println("New age " + customer.getAge());
	/*
	 * Testing the setAdress method bellow 
	 */
		customer.setAddress("");
	/*
	 * testing the setName function 
	 */
		customer.setName("");
		/*
		 * testing the setPhoneNumber method
		 */
		customer.setPhoneNumber("");
	}
}
