package com.revature.exception;

public class InvalidAgeException extends Exception{
	
       public InvalidAgeException(String msg) {
    	   super(msg);
    	   
       }
}
