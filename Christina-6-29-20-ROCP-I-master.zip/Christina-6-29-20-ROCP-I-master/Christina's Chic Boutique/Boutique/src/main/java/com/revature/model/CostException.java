package com.revature.model;

public class CostException extends Exception {
	@SuppressWarnings("serial")
		public CostException(String errorMessage) {
			super(errorMessage);
		}
	}

