package com.revature.model;


public class Pants extends Product implements MachineWashable{
	
	public Pants() {
		super();		
	}
	public Pants(float Cost, int Availability, String PrintPattern, String Brand, String Material, int Size)  {
		// catches if the user enters a negative cost for a dress
				this.Cost=Cost;
					if(Cost<0) 
						try{
						throw new CostException("Cost is not supposed to be a negative value.");
						}// closing try 
						catch (CostException e) {
							e.printStackTrace();
						}
						
						// Making sure availability is never less than 0
						if (Availability < 0) {
							this.Availability = 0;
						} else {
							this.Availability=Availability;
						}
						
						this.PrintPattern=PrintPattern;
						this.Brand=Brand;
						this.Material=Material;
						this.Size=Size;
	}
	@Override
	public boolean isWashable() {
		
		return true;
	}

	@Override
	public float ProductConfig(int Availability, String Material) {
		
		return 0;
	}
	// A test to make sure our method and constructor are working
	public static void main(String[] args) {
		Pants p = new Pants(25f, 100, "PinStripe", "Versacci", "Denim", 5);
		// This should update to cost of the dress from $60 to $62
		p.ProductConfig(99, "Wool");
		System.out.print(p.Cost);
	}
	}
