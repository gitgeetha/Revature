package com.revature.model;

public class Store{

	private String storeName = "n/a"; //Name of the store
	private String storeLocation = "n/a";
	private static int inventory; 
	private int employees; 
	private float shippingTime;
	
	
	public Store (int employees, int inventory, String storeName, String storeLocation) {
		if((employees>0)&&(inventory>0)) {
		this.employees = employees;
		this.inventory = inventory;
		this.storeName = storeName;
		this.storeLocation = storeLocation;
		}
		else System.out.println("Invalid input. Try again.");
	
	}
	

	public static float shippingCalculation(float shippingTime, int employees) {
	if (employees < 1) {
		return shippingTime;
	}
	else	return shippingTime/employees;
	}
	
	public 	void storeCity(String storeLocation) {
		this.storeLocation = storeLocation;
	}
	
	
	
	public Store() {
	
	}
	
	
	public String getStoreName() {
		return storeName;
	}


	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}


	public String getStoreLocation() {
		return storeLocation;
	}


	public void setStoreLocation(String storeLocation) {
		this.storeLocation = storeLocation;
	}


	public int getInventory() {
		return inventory;
	}


	public void setInventory(int inventory) {
		this.inventory = inventory;
		if (this.inventory<100) {
		try {throw new CustomException("Too low of stock!");}
	
		catch (CustomException e) {e.printStackTrace();}
	}
	}

	public int getEmployees() {
		return employees;
	}


	public void setEmployees(int employees) {
		this.employees = employees;
	}


	public float getShippingTime() {
		return shippingTime;
	}


	public void setShippingTime(float shippingTime) {
		this.shippingTime = shippingTime;
	}
	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + employees;
		result = prime * result + inventory;
		result = prime * result + Float.floatToIntBits(shippingTime);
		result = prime * result + ((storeLocation == null) ? 0 : storeLocation.hashCode());
		result = prime * result + ((storeName == null) ? 0 : storeName.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Store other = (Store) obj;
		if (employees != other.employees)
			return false;
		if (inventory != other.inventory)
			return false;
		if (Float.floatToIntBits(shippingTime) != Float.floatToIntBits(other.shippingTime))
			return false;
		if (storeLocation == null) {
			if (other.storeLocation != null)
				return false;
		} else if (!storeLocation.equals(other.storeLocation))
			return false;
		if (storeName == null) {
			if (other.storeName != null)
				return false;
		} else if (!storeName.equals(other.storeName))
			return false;
		return true;
	}
	
	


	@Override
	public String toString() {
		return "Store [storeName=" + storeName + ", storeLocation=" + storeLocation + ", inventory=" + inventory
				+ ", employees=" + employees + ", shippingTime=" + shippingTime + "]";
	}


	public static void main(String []args) {
		
		Store boutique = new Store(3, 50, "Christina's Chic Boutique", "Los Angeles");
		//boutique.storeName = "Christina's Chic Boutique";
		//boutique.storeLocation = "Los Angeles";
		//boutique.inventory = 50; 
		//boutique.employees = 3;
		boutique.shippingTime = 7; 
		boutique.setInventory(6); //The CustomException was already handled in the setInventory method.

		
		System.out.println("Your package will ship in: " + shippingCalculation (boutique.shippingTime,boutique.employees)+ " days. Thank you for your order.");
	    System.out.println(boutique.storeName);
	    System.out.println(boutique.storeLocation);
	    
	    
	}
	
	
}