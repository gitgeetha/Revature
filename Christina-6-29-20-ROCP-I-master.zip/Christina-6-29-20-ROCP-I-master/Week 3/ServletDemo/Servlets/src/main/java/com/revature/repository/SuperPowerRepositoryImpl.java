package com.revature.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.revature.model.SuperPower;
import com.revature.util.ConnectionClosers;
import com.revature.util.ConnectionFactory;

public class SuperPowerRepositoryImpl implements SuperPowerRepository {

	@Override
	public List<SuperPower> findAllSuperPowers() {
		/*
		 * Let's retrieve all of our super powers!
		 */
		Connection conn = null;
		Statement stmt = null;
		ResultSet set = null; // this will store the records we retrieve from our DB
		final String SQL = "select * from super_power";
		List<SuperPower> superPowers = new ArrayList<>();

		try {
			conn = ConnectionFactory.getConnection();
			stmt = conn.createStatement();
			set = stmt.executeQuery(SQL);

			while (set.next()) {
				superPowers.add(new SuperPower(set.getInt(1), set.getString(2)));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			ConnectionClosers.closeConnection(conn);
			ConnectionClosers.closeResultSet(set);
			ConnectionClosers.closeStatement(stmt);
		}

		/*
		 * What if I wanted to take the data I received from the data source
		 * and modify it in some way for the presentation?
		 * 
		 * Note that if you choose to perform the business logic here, you will
		 * not be able to reuse this data access method to simply pull all of the
		 * records.
		 */
		
//		for(SuperPower power : superPowers) {
//			power.setPowerName(power.getPowerName().concat(" is a power."));
//		}
		
		return superPowers;
	}

	@Override
	public SuperPower findSuperPowerById(int id) {
		SuperPower superPower = null;
		
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet set = null;
		final String SQL = "select * from super_power where id = ?";
		
		try {
			conn = ConnectionFactory.getConnection();
			stmt = conn.prepareStatement(SQL);
			stmt.setInt(1, id);
			set = stmt.executeQuery();
			
			if(set.next()) {
				superPower = new SuperPower(set.getInt(1), set.getString(2));
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			ConnectionClosers.closeConnection(conn);
			ConnectionClosers.closeStatement(stmt);
			ConnectionClosers.closeResultSet(set);
		}
		
		return superPower;
	}

	@Override
	public void insertSuperPower(SuperPower superPower) {
		/*
		 * Let's attempt to insert a new record into the super_power table. In order to
		 * do this, we first have to establish a connection to the database by using the
		 * DriverManager class.
		 */

		Connection conn = null; // I will store a connection for later use.
		Statement stmt = null; // object representation of our SQL statement.

		try {
			conn = ConnectionFactory.getConnection();
			stmt = conn.createStatement(); // use our connection to create a statement object
			/*
			 * Notice that we did not use a semicolon at the end of our SQL string. This is
			 * not required in JDBC as that is handled for you.
			 */
			stmt.execute("insert into super_power values(default, '" + superPower.getPowerName() + "')");

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			/*
			 * You must ALWAYS close your connections!
			 */
			ConnectionClosers.closeConnection(conn);
			ConnectionClosers.closeStatement(stmt);
		}
	}

	@Override
	public void deleteSuperPower(SuperPower superPower) {
		// TODO Auto-generated method stub

	}

	@Override
	public void updateSuperPower(SuperPower superPower) {

		Connection conn = null;
		Statement stmt = null;

		try {
			conn = ConnectionFactory.getConnection();
			stmt = conn.createStatement();
			stmt.execute("update super_power set powername = '" + superPower.getPowerName() + "' where id = "
					+ superPower.getId());
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			ConnectionClosers.closeConnection(conn);
			ConnectionClosers.closeStatement(stmt);
		}
	}

	@Override
	public SuperPower findSuperPowerByName(String name) {
		// When a reference points to "null", it is not pointing to an object.
		// This means that I cannot call methods on this reference!
		SuperPower superPower = null;
		Connection conn = null;
		// Let's use a PreparedStatement instead!
		PreparedStatement stmt = null;
		ResultSet set = null;
		/*
		 * When using a PreparedStatement, you are allowed to parameterize the data that
		 * you are attempting to insert or parameterize the values in your "where"
		 * clauses.
		 * 
		 * NOTE: PreparedStatements allow us to precompile our SQL statements such that
		 * the parameters we specify have strict types imposed on them.
		 */

		/*
		 * Your parameter index corresponds to the placement of your "?". If the "?" is
		 * the first "?", its parameter is 1.
		 * 
		 * EXAMPLE:
		 * 
		 * insert into super_power values(default, ?) //question mark's parameter value
		 * is 1
		 */
		final String SQL = "select * from super_power where powername = ?";

		try {
			conn = ConnectionFactory.getConnection();
			/*
			 * This is not good practice as it leaves you vulnerable to SQL injection. If
			 * the user is crafty and places SQL in their input, they could cause your
			 * application to throw exceptions or even drop tables/grab data from your
			 * database.
			 */
//			stmt = conn.createStatement();

			stmt = conn.prepareStatement(SQL);
			stmt.setString(1, name); // make the first parameter's value the value of the "name" variable
			set = stmt.executeQuery();

//			set = stmt.executeQuery("select * from super_power where powername = '" + name + "'");

			if (set.next()) { // I only need one super power from the database.
				superPower = new SuperPower(set.getInt(1), set.getString(2));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			ConnectionClosers.closeConnection(conn);
			ConnectionClosers.closeResultSet(set);
			ConnectionClosers.closeStatement(stmt);
		}

		return superPower;
	}

}
