package com.revature.service;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.revature.model.SuperPower;
import com.revature.repository.SuperPowerRepository;
import com.revature.repository.SuperPowerRepositoryImpl;

/*
 * Instead of embedding business logic into the repository layer, we can
 * create a layer of our application that is devoted to business logic so
 * that we can maintain the integrity of our data access layer.
 */
public class SuperPowerService {

	SuperPowerRepository superPowerRepository;
	
	public SuperPowerService() {
		this.superPowerRepository = new SuperPowerRepositoryImpl();
	}
	
	public List<SuperPower> appendToSuperPowerName(String s){
		List<SuperPower> powers = this.superPowerRepository.findAllSuperPowers();
		
		for(SuperPower power : powers) {
			power.setPowerName(power.getPowerName() + " " + s);
		}
		
		return powers;
	}
	
	public SuperPower findSuperPowerByName(String name) {
		return this.superPowerRepository.findSuperPowerByName(name);
	}
	
	public void insertPowerSuper(SuperPower superPower) {
		/*
		 * This would be the point at which I performed business logic! If,
		 * for instance, I needed to sanitize the user input, I would do it here!
		 */
		this.superPowerRepository.insertSuperPower(superPower);
	}
	
	//I will create an overloaded version of insertPowerSuper that is consistent
	//with my FrontController design pattern!
	
	public void insertPowerSuper(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{
		
		String powerName = request.getParameter("newpower");
		
		this.superPowerRepository.insertSuperPower(new SuperPower(1, powerName));
	}
	
	public SuperPower findSuperPowerById(int id) {
		return this.superPowerRepository.findSuperPowerById(id);
	}
	
	public List<SuperPower> findAllSuperPowers(){
		return this.superPowerRepository.findAllSuperPowers();
	}
}
